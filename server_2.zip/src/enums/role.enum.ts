export enum Role {
  ADMIN = 'admin',
  USER = 'user',
  User = "User",
  Admin = "Admin",
}
