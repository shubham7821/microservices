// import { Body, Controller, Get, Post, UseGuards, Request, UsePipes, ValidationPipe } from '@nestjs/common';
// import { ApiOperation, ApiBearerAuth, ApiTags } from '@nestjs/swagger';
// import  JwtAuthGuard  from '../auth/guards/jwt-auth.guard'; // Ensure correct import
// import { RolesGuard } from '../auth/guards/roles.guard'; // Ensure correct import
// // import { Roles } from '../auth/decorator/roles.decorator'; // Correctly import the Roles decorator
// import { Role } from '../enums/role.enum'; // Ensure the Role enum is correctly imported
// import { CreateUserDto } from './dto/create-user.dto';
// import { UsersService } from './users.service';
// import { CurrentUser } from '../auth/decorator/current-user.decorator'; // Ensure this is the correct decorator

// @ApiTags('User Management') // Swagger tag for all endpoints in this controller
// @Controller('user')
// export class UsersController {
//   constructor(private readonly usersService: UsersService) {}

//   @Post('/signup')
//   @ApiOperation({ summary: 'Sign up as a user' })
//   @UsePipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))
//   create(@Body() createUserDto: CreateUserDto) {
//     return this.usersService.create(createUserDto);
//   }
  
//   @UseGuards(JwtAuthGuard)
//   @Get('/profile')
//   @ApiOperation({ summary: 'Get user profile' })
//   @ApiBearerAuth()
//   getProfile(@CurrentUser() user: any) {
//     return user;
//   }
  
 
// }


import { Body, Controller, Get, Param, Post, Put, UseGuards, UsePipes, ValidationPipe } from '@nestjs/common';
import { ApiOperation, ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import  JwtAuthGuard  from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorator/roles.decorator'; // Updated import path if necessary
import { Role } from '../enums/role.enum';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { UsersService } from './users.service';
import { CurrentUser } from '../auth/decorator/current-user.decorator';

@ApiTags('User Management')
@Controller('user')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Post('/signup')
  @ApiOperation({ summary: 'Sign up as a user' })
  @UsePipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))
  create(@Body() createUserDto: CreateUserDto) {
    return this.usersService.create(createUserDto);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN) // Apply role checks
  @Post('/create')
  @ApiOperation({ summary: 'Create a user (admin only)' })
  @ApiBearerAuth()
  createUser(@Body() createUserDto: CreateUserDto) {
    return this.usersService.create(createUserDto);
  }
  
  @UseGuards(JwtAuthGuard)
  @Get('/profile')
  @ApiOperation({ summary: 'Get user profile' })
  @ApiBearerAuth()
  getProfile(@CurrentUser() user: any) {
    return user;
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN, Role.USER) // Accessible to both admins and users
  @Get('/profiles')
  @ApiOperation({ summary: 'Get profiles for admins and users' })
  @ApiBearerAuth()
  getUserProfiles() {
    return this.usersService.findAll();
  }


  // @Get('/me')
  // @UseGuards(JwtAuthGuard)
  // @ApiBearerAuth()
  // getProfile(@CurrentUser() req) {
  //     return req.user; // Returns the user object attached to the request
  // }
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN) // Apply role checks
  @Get('/users')
  @ApiOperation({ summary: 'Get all users (admin only)' })
  @ApiBearerAuth()
  getAllUsers() {
    return this.usersService.findAll();
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.ADMIN) // Apply role checks
  @Get('/users/:id')
  @ApiOperation({ summary: 'Get user by ID (admin only)' })
  @ApiBearerAuth()
  getUserById(@Param('id') id: string) {
    return this.usersService.findById(id);
  }

  @UseGuards(JwtAuthGuard)
  @Put('/profile')
  @ApiOperation({ summary: 'Update user profile' })
  @ApiBearerAuth()
  updateProfile(@CurrentUser() user: any, @Body() updateUserDto: UpdateUserDto) {
    return this.usersService.update(user.id, updateUserDto);
  }
}
